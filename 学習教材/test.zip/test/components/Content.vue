<template>
  <div>
    <div class="content-title">{{ element.title }}</div>
    <label class="zipcode"
      >郵便番号
      <input :value="zipcode" type="text" class="zipcode" @input="onInput" />
    </label>
  </div>
</template>

<script lang="ts">
import Vue, { PropOptions } from 'vue'
import { Element } from '~/store/contents'

export default Vue.extend({
  name: 'Content',
  props: {
    element: {
      type: Object,
      required: true,
    } as PropOptions<Element>,
    zipcode: {
      type: String,
      required: true,
    } as PropOptions<string>,
  },
  methods: {
    onInput(event: { target: { value: string } }) {
      this.$emit('input', event.target.value)
    },
  },
})
</script>

<style scoped></style>
