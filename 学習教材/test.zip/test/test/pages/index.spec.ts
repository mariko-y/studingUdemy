import { shallowMount, Wrapper } from '@vue/test-utils'
import axios from 'axios'
import Index from '@/pages/index.vue'
const flushPromises = require('flush-promises')

describe('/pages/index.vue', () => {
  let index: Wrapper<Vue>
  const elementsData = [
    {
      title: 'コンテンツ１',
      page: './contents1',
    },
    {
      title: 'コンテンツ２',
      page: './contents2',
    },
  ]
  const storeSpy = {
    commit: jest.fn(),
  }
  const routerSpy = {
    push: jest.fn(),
  }
  const responseData = '東京都港区赤坂'
  const axiosGetSpyStub = jest
    .spyOn(axios, 'get')
    .mockResolvedValue(responseData)

  beforeEach(() => {
    index = shallowMount(Index, {
      mocks: { $router: routerSpy, $store: storeSpy },
    })
  })

  it('1.タイトルが表示される', () => {
    expect(index.find('.title').text()).toEqual('テストページ')
  })

  it('6.ページを開くと、コンテンツ用エレメントをstoreにコミットする', () => {
    const expectedElements = elementsData

    expect(storeSpy.commit).toHaveBeenCalledWith(
      'contents/updateElements',
      expectedElements
    )
  })

  // xit('2.設定されたコンテンツが表示され、エレメントが渡せている', () => {
  //   const expectedElements = [
  //     {
  //       title: 'コンテンツ１',
  //       page: './contents1',
  //     },
  //     {
  //       title: 'コンテンツ２',
  //       page: './contents2',
  //     },
  //   ]
  //   expect(index.find('contents-stub').props().elements).toEqual(
  //     expectedElements
  //   )
  // })

  it('5.設定された数分コンテンツが表示され、エレメントが渡せている', () => {
    const contents = index.findAll('contents-stub')

    elementsData.forEach((content, index) => {
      expect(contents.at(index).props().element).toEqual(content)
      expect(contents.at(index).props().zipcode).toEqual('')
    })
  })

  // xit('7.郵便番号入力用ラベルを表示する', () => {
  //   expect(index.findAll('label.zipcode').length).toEqual(1)
  //   expect(index.find('label.zipcode').text()).toEqual('郵便番号')
  // })

  // xit('8.郵便番号入力用テキストフォームを表示する', () => {
  //   expect(index.findAll('input.zipcode').length).toEqual(1)
  //   expect(index.find('input.zipcode').attributes().type).toEqual('text')
  //   expect(index.vm.$data.zipcode).toEqual('')
  // })

  describe('次へボタン', () => {
    it('3.ボタンが表示されている', () => {
      expect(index.find('button.next').text()).toEqual('次へ')
    })

    describe('郵便番号を入力し、ボタンを押下する', () => {
      const zipcode: string = '1070052'
      beforeEach(async () => {
        // index.find('input.zipcode').setValue(zipcode)
        index.find('Contents-stub').vm.$emit('input', zipcode)
        index.find('button.next').trigger('click')
        await flushPromises()
      })

      it('13.子のコンポーネントからinputイベントを受け取ってzipcodeを更新している', () => {
        expect(index.vm.$data.zipcode).toEqual(zipcode)
      })

      it('9.郵便番号を渡して住所取得APIをコールする', () => {
        expect(axiosGetSpyStub).toHaveBeenCalledWith(
          `https://zipcloud.ibsnet.co.jp/api/search?zipcode=${zipcode}`
        )
      })

      it('10.住所取得APIから取得した住所をストアにcommitする', () => {
        expect(storeSpy.commit).toHaveBeenCalledWith(
          'contents/updateAddress',
          responseData
        )
      })

      it('4.トップページに遷移すること', () => {
        expect(routerSpy.push).toHaveBeenCalledWith('./Top')
      })
    })

    // xdescribe('ボタンを押下する', () => {
    //   beforeEach(() => {
    //     index.find('button.next').trigger('click')
    //   })
    //
    //   it('4.トップページに遷移すること', () => {
    //     expect(routerSpy.push).toHaveBeenCalledWith('./Top')
    //   })
    // })
  })
})
