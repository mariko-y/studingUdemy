import { shallowMount, Wrapper } from '@vue/test-utils'
import { Element } from '@/store/contents'
import Content from '../../components/Content.vue'

describe('/components/Content.vue', () => {
  let content: Wrapper<Vue>
  const props = {
    element: {
      title: 'コンテンツタイトル',
      page: './TestContents',
    } as Element,
    zipcode: '',
  }

  beforeEach(() => {
    content = shallowMount(Content, { propsData: props })
  })

  it('5.コンテンツタイトルが表示されている', () => {
    expect(content.find('.content-title').text()).toEqual(props.element.title)
  })

  it('11.郵便番号入力用ラベルを表示する', () => {
    expect(content.findAll('label.zipcode').length).toEqual(1)
    expect(content.find('label.zipcode').text()).toEqual('郵便番号')
  })

  it('12.親クラスから渡された値で、郵便番号入力用テキストフォームを表示する', () => {
    expect(content.findAll('input.zipcode').length).toEqual(1)
    expect(content.find('input.zipcode').attributes().type).toEqual('text')
    expect(content.vm.$props.zipcode).toEqual(props.zipcode)
  })

  it('13.入力されるとinputイベントを発行して、値が親クラスにemitされる', () => {
    const zipcode = '1070052'
    content.find('input.zipcode').setValue(zipcode)

    const event = content.emitted().input
    if (!event) throw new Error('イベントが発行されていない')

    expect(event.length).toEqual(1)
    expect(event[0][0]).toEqual(zipcode)
  })
})
