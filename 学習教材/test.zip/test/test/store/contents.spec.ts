import Vue from 'vue'
import Vuex, { Store } from 'vuex'
import { ContentsState, Element } from '@/store/contents'
const Contents = require('@/store/contents')
const cloneDeep = require('lodash/cloneDeep')

describe('/store/contents', () => {
  let contents: Store<ContentsState>

  beforeEach(() => {
    Vue.use(Vuex)
    contents = new Vuex.Store(cloneDeep(Contents))
  })

  it('6.エレメントの更新ができる', () => {
    contents.commit('updateElements', [])
    expect(contents.state.elements).toEqual([])

    const elementsData: Array<Element> = [
      {
        title: 'コンテンツタイトル1',
        page: './Test1',
      },
      {
        title: 'コンテンツタイトル2',
        page: './Test2',
      },
    ]

    contents.commit('updateElements', elementsData)
    expect(contents.state.elements).toEqual(elementsData)
  })

  it('10.アドレスの更新ができる', () => {
    contents.commit('updateAddress', '')
    expect(contents.state.address).toEqual('')

    const contentsData: string = ''

    contents.commit('updateAddress', contentsData)
    expect(contents.state.address).toEqual(contentsData)
  })
})
