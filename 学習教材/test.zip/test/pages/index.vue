<template>
  <div class="container">
    <div class="title">テストページ</div>
    <template v-for="(element, index) in elements">
      <!--      <Contents :key="index" :element="element" />-->
      <Contents
        :key="index"
        :element="element"
        :zipcode="zipcode"
        @input="onInput"
      />
    </template>
    <!--    <label class="zipcode"-->
    <!--      >郵便番号-->
    <!--      <input :value="zipcode" type="text" class="zipcode" @input="onInput" />-->
    <!--    </label>-->
    <button class="next" @click="goToNextPage">次へ</button>
  </div>
</template>

<script lang="ts">
import Vue from 'vue'
import axios from 'axios'
import Contents from '~/components/Content.vue'

export default Vue.extend({
  name: 'Index',
  components: { Contents },
  data() {
    return {
      elements: [
        {
          title: 'コンテンツ１',
          page: './contents1',
        },
        {
          title: 'コンテンツ２',
          page: './contents2',
        },
      ],
      zipcode: '',
    }
  },
  created() {
    this.$store.commit('contents/updateElements', this.elements)
  },
  methods: {
    async goToNextPage(): Promise<void> {
      const address = await axios.get(
        `https://zipcloud.ibsnet.co.jp/api/search?zipcode=${this.zipcode}`
      )
      this.$store.commit('contents/updateAddress', address)
      await this.$router.push('./Top')
    },
    onInput(event: string): void {
      // this.zipcode = event.target.value
      this.zipcode = event
    },
  },
})
</script>

<style></style>
