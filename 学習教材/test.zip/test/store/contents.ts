import { MutationTree } from 'vuex'

export type Element = {
  title: string
  page: string
}

export interface ContentsState {
  elements: Array<Element>
  address: string
}

export const state: () => ContentsState = () => {
  return {
    elements: [],
    address: '',
  }
}

export const mutations: MutationTree<ContentsState> = {
  updateElements(state, payload: Array<Element>) {
    state.elements = payload
  },
  updateAddress(state, payload: string) {
    state.address = payload
  },
}
